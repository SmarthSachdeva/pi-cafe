package com.picafe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PiCafeApplication {

	public static void main(String[] args) {
		SpringApplication.run(PiCafeApplication.class, args);
	}

}
